﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace belous24._3
{
    class Student
    {
        private string fullName;
        private char gender;
        private int birthYear;

        public string FullName
        {
            get { return fullName; }
            set { fullName = value; }
        }

        public char Gender
        {
            get { return gender; }
            set
            {
                if (value == 'М' || value == 'Ж')
                    gender = value;
                else
                    throw new ArgumentException("Выберите пол 'М' или 'Ж'.");
            }
        }

        public int BirthYear
        {
            get { return birthYear; }
            set
            {
                if (value > 1900 && value <= DateTime.Now.Year)
                    birthYear = value;
                else
                    throw new ArgumentException("Неверный год рождения.");
            }
        }

        public Student(string fullName, char gender, int birthYear)
        {
            FullName = fullName;
            Gender = gender;
            BirthYear = birthYear;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите количесто учеников: ");
            int n = int.Parse(Console.ReadLine());

            Student[] students = new Student[n];

            for (int i = 0; i < n; i++)
            {
                Console.WriteLine($"\nВведите инфомацию об ученике {i + 1}:");
                Console.Write("Полное имя: ");
                string fullName = Console.ReadLine();
                Console.Write("Пол (М/Ж): ");
                char gender = char.ToUpper(Console.ReadKey().KeyChar);
                Console.WriteLine();
                Console.Write("Год рождения: ");
                int birthYear = int.Parse(Console.ReadLine());

                students[i] = new Student(fullName, gender, birthYear);
            }

            int maleCount = 0;
            int femaleCount = 0;

            foreach (Student student in students)
            {
                if (student.Gender == 'М')
                    maleCount++;
                else
                    femaleCount++;
            }

            Console.WriteLine($"\nКоличесто студентов мужского пола: {maleCount}");
            Console.WriteLine($"Количесто студентов женского пола: {femaleCount}");
            Console.ReadKey();
                
        }
    }
}
