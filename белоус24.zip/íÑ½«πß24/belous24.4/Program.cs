﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace belous24._4
{
    using System;

    class Flight
    {
        // Поля класса
        private string flightNumber;
        private DateTime departureTime;
        private DateTime arrivalTime;
        private string destination;

        // Свойства класса с проверкой значений
        public string FlightNumber
        {
            get { return flightNumber; }
            set
            {
                if (!string.IsNullOrEmpty(value))
                    flightNumber = value;
                else
                    throw new ArgumentException("Flight number cannot be null or empty.");
            }
        }

        public DateTime DepartureTime
        {
            get { return departureTime; }
            set { departureTime = value; }
        }

        public DateTime ArrivalTime
        {
            get { return arrivalTime; }
            set
            {
                if (value > departureTime)
                    arrivalTime = value;
                else
                    throw new ArgumentException("Arrival time must be after departure time.");
            }
        }

        public string Destination
        {
            get { return destination; }
            set
            {
                if (!string.IsNullOrEmpty(value))
                    destination = value;
                else
                    throw new ArgumentException("Destination cannot be null or empty.");
            }
        }

        // Конструктор с параметрами
        public Flight(string flightNumber, DateTime departureTime, DateTime arrivalTime, string destination)
        {
            FlightNumber = flightNumber;
            DepartureTime = departureTime;
            ArrivalTime = arrivalTime;
            Destination = destination;
        }

        // Метод для вывода информации о рейсе
        public void PrintInfo()
        {
            Console.WriteLine($"Номер рейса: {FlightNumber}, Время вылета: {DepartureTime.ToString("dd/MM/yyyy HH:mm")}, Время прилета: {ArrivalTime.ToString("dd/MM/yyyy HH:mm")}, Пункт назначения: {Destination}");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Ввод количества рейсов
            Console.Write("Введите количество рейсов: ");
            int n = int.Parse(Console.ReadLine());

            // Создание массива объектов класса Flight
            Flight[] flights = new Flight[n];

            // Ввод информации о рейсах
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine($"Введите информацию о рейсе {i + 1}:");
                Console.Write("Номер рейса: ");
                string flightNumber = Console.ReadLine();
                Console.Write("Время вылета: ");
                DateTime departureTime = DateTime.Parse(Console.ReadLine());
                Console.Write("Время прилета: ");
                DateTime arrivalTime = DateTime.Parse(Console.ReadLine());
                Console.Write("Пункт назначения: ");
                string destination = Console.ReadLine();

                // Создание объекта рейса и добавление его в массив
                flights[i] = new Flight(flightNumber, departureTime, arrivalTime, destination);
            }

            // Ввод города, для которого нужно вывести информацию о рейсах
            Console.WriteLine("Введите город: ");
            string city = Console.ReadLine();

            // Вывод информации о рейсах в заданный город
            Console.WriteLine($"Рейсы в город {city}:");
            
            foreach (var flight in flights)
            {
                if (flight.Destination.Equals(city, StringComparison.OrdinalIgnoreCase))
                {
                    flight.PrintInfo();
                }
                
            }
           
            Console.ReadKey();
        }
    }
}
