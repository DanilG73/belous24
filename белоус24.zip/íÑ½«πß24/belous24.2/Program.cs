﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace belous24._2
{
    
    class Parallelogram
    {
        public static int NumOfSquares = 0;
        public static int NumOfRectangles = 0;
        public static int NumOfRhombuses = 0;

        public double A { get; }
        public double B { get; }
        public double Alpha { get; }

        public Parallelogram(double a, double b, double alpha)
        {
            A = a;
            B = b;
            Alpha = alpha;
            if (IsSquare())
            {
                NumOfSquares++;
            }
            else if (IsRectangle())
            {
                NumOfRectangles++;
            }
            else if (IsRhombus())
            {
                NumOfRhombuses++;
            }
        }

        public bool IsSquare()
        {
            return A == B && Alpha == 90;
        }

        public bool IsRectangle()
        {
            return Alpha == 90;
        }

        public bool IsRhombus()
        {
            return A == B;
        }

        public static void GetCounts()
        {
            Console.WriteLine("Количество квадратов: " + NumOfSquares);
            Console.WriteLine("Количество прямоугольников: " + NumOfRectangles);
            Console.WriteLine("Количество ромбов: " + NumOfRhombuses);
        }
    }

    class Program
    {

        static void Main()
        {
            List<Parallelogram> parallelograms = new List<Parallelogram>();
            Console.Write("Введите количество парралелограммов: ");
            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                Console.Write("Введите длину стороны A: ");
                double a = double.Parse(Console.ReadLine());
                Console.Write("Введите длину стороны B: ");
                double b = double.Parse(Console.ReadLine());
                Console.Write("Введите угол альфа: ");
                double alpha = double.Parse(Console.ReadLine());
                parallelograms.Add(new Parallelogram(a, b, alpha));
            }

            Parallelogram.GetCounts();
            Console.ReadKey();
        }
    }
}

